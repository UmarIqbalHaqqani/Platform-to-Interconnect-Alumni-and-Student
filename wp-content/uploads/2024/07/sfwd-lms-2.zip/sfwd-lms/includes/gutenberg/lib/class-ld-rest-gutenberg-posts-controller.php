<?php
/**
 * LearnDash Gutenberg Posts Controller.
 *
 * @since 2.5.8
 * @deprecated 4.10.3 {@see 'src/Core/API/Controllers/Posts.php'} instead.
 *
 * @package LearnDash
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once LEARNDASH_LMS_PLUGIN_DIR . '/src/deprecated/LD_REST_Posts_Gutenberg_Controller.php';
